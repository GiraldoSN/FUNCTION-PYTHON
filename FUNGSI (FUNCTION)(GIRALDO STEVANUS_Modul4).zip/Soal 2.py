#Progran untuk bilangan Fibonacci dengan menggunakan function
import numbers


def fibo(n):
    if n == 0:
        return [n]
        
    number = fibo(n-1)
    indek = len(number)

    angka1 = number[-2] if indek > 2 else 0
    angka2 = number[-1] if indek > 2 else 0

    return number + [angka1 + angka2]


angka = int(input("masukkan angka : "))

print(fibo(angka-1))