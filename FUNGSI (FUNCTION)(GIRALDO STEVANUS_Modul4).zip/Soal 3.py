#Program menampilkan segitiga bintang menggunakan fuction yang menerima 2 parameter. Parameter yang pertama untuk menentukan tinggi segitiga, dan parameter yang kedua untuk menentukan jumlah segitiga yang akan ditampilkan
def segitiga(x):
    for i in range(1,x+1):
        print("*" * i)
y = int (input("Berapa segitiga yang mau dibuat : "))
z = int (input("Berapa bintang yang mau dimasukkan : "))
for i in range(y):
    print("")
    segitiga(z)