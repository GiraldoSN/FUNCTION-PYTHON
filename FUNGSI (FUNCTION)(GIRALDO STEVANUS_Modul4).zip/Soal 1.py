#Program Konverensi Suhu dengan menggunakan Function
def suhu (x):
    r = (x *4/5)
    f = (x* 9/5)+32
    k = x + 273
    print("Suhu dalam Reamur: ", r)
    print("Suhu dalam Fahreinheit: ", f)
    print("Suhu dalam Kelvin: ", k)

a = int(input("Madukkan suhu dalam celcius: "))
suhu (a)